"""Safety and comparison checks for the baseline runner (standard-library only)."""

import contextlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from tools import baseline


class BaselineTests(unittest.TestCase):
    def test_existing_output_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            sentinel = Path(directory) / "summary.json"
            sentinel.write_text("keep this report")
            with patch.object(baseline, "check_environment", return_value={}):
                with patch("sys.argv", ["baseline", "--output", directory]):
                    with self.assertRaises(FileExistsError):
                        baseline.main()
            self.assertEqual(sentinel.read_text(), "keep this report")

    def test_failed_commands_keep_diagnostics_and_nonzero_exit(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            result, _ = baseline.run_command(
                "failure", ["_gana_intentionally_missing_module"], output,
                {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}, output,
            )
            self.assertNotEqual(result["exit_code"], 0)
            self.assertIn("No module named", (output / "failure.stderr.txt").read_text())

    def test_replay_detects_source_environment_and_metric_changes(self):
        original = {
            "python": "3.13.7", "platform": "reference", "machine": "x86_64",
            "packages": {"pytest": "8.4.2"}, "seed": "20260921", "environment": {},
            "interpreter": "/original/python", "created_utc": "old",
        }
        hashes = {"src/gana/__init__.py": "abc"}
        metrics = {"tests": {"tests": 14, "failures": 0}}
        with tempfile.TemporaryDirectory() as directory:
            reference, output = Path(directory) / "reference", Path(directory) / "output"
            reference.mkdir()
            output.mkdir()
            baseline.write_json(reference / "manifest.json", original)
            baseline.write_json(reference / "source-hashes.json", hashes)
            baseline.write_json(reference / "summary.json", metrics)
            for change in (None, "source", "environment", "metrics"):
                with self.subTest(change=change):
                    current = {**original, "interpreter": "/rebuilt/python", "created_utc": "new"}
                    if change == "environment":
                        current["packages"] = {"pytest": "other-version"}
                    baseline.write_json(output / "manifest.json", current)
                    inputs = {} if change == "source" else hashes
                    values = {} if change == "metrics" else metrics
                    with contextlib.redirect_stdout(io.StringIO()):
                        matches = baseline.compare(reference, output, inputs, values)
                    self.assertEqual(matches, change is None)
                    self.assertEqual(
                        json.loads((output / "comparison.json").read_text())["same_source"],
                        change != "source",
                    )


if __name__ == "__main__":
    unittest.main()
